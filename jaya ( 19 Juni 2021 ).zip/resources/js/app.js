require('./bootstrap');
mix.js('resources/js/app.js', 'public/js');