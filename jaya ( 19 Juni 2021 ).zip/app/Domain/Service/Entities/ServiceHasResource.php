<?php

namespace App\Domain\Service\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceHasService extends Model
{
    use HasFactory;
}
