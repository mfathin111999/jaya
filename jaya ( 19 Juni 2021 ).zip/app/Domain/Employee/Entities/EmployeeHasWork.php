<?php

namespace App\Domain\Employee\Entities;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeHasWork extends Model
{
    use HasFactory;
}
