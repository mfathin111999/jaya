<?php

namespace App\Domain\Payment\Application;

class PaymentManagement
{

}