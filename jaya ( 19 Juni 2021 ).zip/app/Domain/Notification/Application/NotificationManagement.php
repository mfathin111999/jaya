<?php

namespace App\Domain\Notification\Application;

class NotificationManagement
{

}